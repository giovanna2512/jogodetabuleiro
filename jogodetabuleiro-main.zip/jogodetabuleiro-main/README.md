# jogodetabuleiro
Criamos um jogo de tabuleiro de corrida com tema de terror, onde os jogadores irão sorteando dados e enfrentando charadas de terror a cada casa que caem. Vamos descrever a estrutura do jogo, regras e como podemos implementá-lo com o uso de arrays bidimensionais para o tabuleiro, além da mecânica para as charadas de terror.
